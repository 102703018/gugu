//
//  SectionData.swift
//  MRT
//
//  Created by Cindy Ku on 2016/5/24.
//  Copyright © 2016年 iOSCourse. All rights reserved.
//

import Foundation
import SwiftyJSON

class  SectionsDataForUse {
    
    func DataFromJSON() -> [Section] {
        
        let path : String = NSBundle.mainBundle().pathForResource("MRT", ofType: "json") as String!
        let jsonData = NSData(contentsOfFile: path) as NSData!
        let usefulJSON = JSON(data: jsonData, options: NSJSONReadingOptions.MutableContainers, error: nil)
        
        
        // line1 to 8 DataArrays
        var FirstlineArray = [String]()
        var SecondlineArray = [String]()
        var ThirdlineArray = [String]()
        var FourthlineArray = [String]()
        var FifthlineArray = [String]()
        var SixthlineArray = [String]()
        var SeventhlineArray = [String]()
        var EightlineArray = [String]()
        
        var FirstlineArrayNum = [[String]]()
        var SecondlineArrayNum = [[String]]()
        var ThirdlineArrayNum = [[String]]()
        var FourthlineArrayNum = [[String]]()
        var FifthlineArrayNum = [[String]]()
        var SixthlineArrayNum = [[String]]()
        var SeventhlineArrayNum = [[String]]()
        var EightlineArrayNum = [[String]]()
        
        var FirstlineArrayName = [[String]]()
        var SecondlineArrayName = [[String]]()
        var ThirdlineArrayName = [[String]]()
        var FourthlineArrayName = [[String]]()
        var FifthlineArrayName = [[String]]()
        var SixthlineArrayName = [[String]]()
        var SeventhlineArrayName = [[String]]()
        var EightlineArrayName = [[String]]()
        
        
        
        for i in 0...usefulJSON.count {
            let name = usefulJSON[i]["name"].stringValue
            let linesName = usefulJSON[i]["lines"].map( { (x: (String, JSON)) -> String in x.0 } )
            let linesNumber = usefulJSON[i]["lines"].map( { (x: (String, JSON)) -> String in x.1.stringValue } )
            
            
            
            if linesName.contains("板南線") {
                FirstlineArray.append(name)
                FirstlineArrayNum.append(linesNumber)
                FirstlineArrayName.append(linesName)
            }
            
            if linesName.contains("文湖線") {
                SecondlineArray.append(name)
                SecondlineArrayNum.append(linesNumber)
                SecondlineArrayName.append(linesName)
            }
            
            if linesName.contains("淡水信義線") {
                ThirdlineArray.append(name)
                ThirdlineArrayNum.append(linesNumber)
                ThirdlineArrayName.append(linesName)
            }
            
            if linesName.contains("松山新店線") {
                FourthlineArray.append(name)
                FourthlineArrayNum.append(linesNumber)
                FourthlineArrayName.append(linesName)
            }
            
            if linesName.contains("中和新蘆線") {
                FifthlineArray.append(name)
                FifthlineArrayNum.append(linesNumber)
                FifthlineArrayName.append(linesName)
                
            }
            
            if linesName.contains("小碧潭支線") {
                SixthlineArray.append(name)
                SixthlineArrayNum.append(linesNumber)
                SixthlineArrayName.append(linesName)
            }
            
            if linesName.contains("新北投支線") {
                SeventhlineArray.append(name)
                SeventhlineArrayNum.append(linesNumber)
                SeventhlineArrayName.append(linesName)
            }
            
            if linesName.contains("貓空纜車") {
                EightlineArray.append(name)
                EightlineArrayNum.append(linesNumber)
                EightlineArrayName.append(linesName)
            }
            
        }
        
        var sectionsArray = [Section]()
        
        let Line1 = Section(title: "板南線", objects: FirstlineArray, num: FirstlineArrayNum, line: FirstlineArrayName)
        let Line2 = Section(title: "文湖線", objects: SecondlineArray, num: SecondlineArrayNum, line: SecondlineArrayName)
        let Line3 = Section(title: "淡水信義線", objects: ThirdlineArray, num: ThirdlineArrayNum, line: ThirdlineArrayName)
        let Line4 = Section(title: "松山新店線", objects: FourthlineArray, num: FourthlineArrayNum, line: FourthlineArrayName)
        let Line5 = Section(title: "中和新蘆線", objects: FifthlineArray, num: FifthlineArrayNum, line: FifthlineArrayName)
        let Line6 = Section(title: "小碧潭支線", objects: SixthlineArray, num: SixthlineArrayNum, line: SixthlineArrayName)
        let Line7 = Section(title: "新北投支線", objects: SeventhlineArray, num: SeventhlineArrayNum, line: SeventhlineArrayName)
        let Line8 = Section(title: "貓空纜車", objects: EightlineArray, num: EightlineArrayNum, line: EightlineArrayName)
        
        sectionsArray.append(Line1)
        sectionsArray.append(Line2)
        sectionsArray.append(Line3)
        sectionsArray.append(Line4)
        sectionsArray.append(Line5)
        sectionsArray.append(Line6)
        sectionsArray.append(Line7)
        sectionsArray.append(Line8)
        
        
        
        
        
        return sectionsArray
        
        
    }
    
    
    
    
}

