//
//  SectionProperty.swift
//  MRT
//
//  Created by Cindy Ku on 2016/5/24.
//  Copyright © 2016年 iOSCourse. All rights reserved.
//

import Foundation

struct Section{
    
    var section : String
    var stations : [String]
    var stationLineNum : [[String]]
    var stationLineName : [[String]]
    
    
    init(title: String, objects : [String], num: [[String]], line: [[String]]) {
        
        section = title
        stations = objects
        stationLineNum = num
        stationLineName = line
    }
    
    
    
    
}