//
//  AnotherTableViewCell.swift
//  MRT
//
//  Created by Cindy Ku on 2016/5/24.
//  Copyright © 2016年 iOSCourse. All rights reserved.
//

import UIKit

class SecondTableViewCell: UITableViewCell {

    
    @IBOutlet var stationNameLabel: UILabel!
    @IBOutlet var firstLineNumLabel: UILabel!
    @IBOutlet var secondLineNumLabel: UILabel!
    @IBOutlet var firstLineNameLabel: UILabel!
    @IBOutlet var secondLineNameLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
