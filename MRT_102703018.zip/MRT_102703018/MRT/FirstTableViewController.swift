//
//  ViewController.swift
//  MRT
//
//  Created by Cindy Ku on 2016/5/24.
//  Copyright © 2016年 iOSCourse. All rights reserved.
//

import UIKit
import SwiftyJSON

class FirstTableViewController: UITableViewController {
    
    var Sections: [Section] = SectionsDataForUse().DataFromJSON()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return Sections.count
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Sections[section].stations.count
    }
    
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if Sections[indexPath.section].stationLineNum[indexPath.row].count == 1 {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("FirstCell", forIndexPath: indexPath) as! FirstTableViewCell
            
            cell.stationNameLabel.text = Sections[indexPath.section].stations[indexPath.row] as String
            
            cell.lineNameLabel.text = Sections[indexPath.section].stationLineName[indexPath.row][0] as String
            cell.lineNameLabel.hidden = true
            
            cell.lineNumLabel.text = Sections[indexPath.section].stationLineNum[indexPath.row][0] as String
            cell.lineNumLabel.textColor = UIColor.whiteColor()
            cell.lineNumLabel.backgroundColor = setLineLabelColor(Sections[indexPath.section].stationLineNum[indexPath.row][0] as String)
            
            return cell
            
        }
            // For the situation that station have two linenumber
        else {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("SecondCell", forIndexPath: indexPath) as! SecondTableViewCell
            
            cell.stationNameLabel.text = Sections[indexPath.section].stations[indexPath.row] as String
            cell.firstLineNumLabel.text = Sections[indexPath.section].stationLineNum[indexPath.row][0] as String
            cell.firstLineNumLabel.backgroundColor = setLineLabelColor(Sections[indexPath.section].stationLineNum[indexPath.row][0] as String)
            cell.firstLineNumLabel.textColor = UIColor.whiteColor()
            cell.firstLineNumLabel.layer.cornerRadius = 3
            
            cell.secondLineNumLabel.text = Sections[indexPath.section].stationLineNum[indexPath.row][1] as String
            cell.secondLineNumLabel.backgroundColor = setLineLabelColor(Sections[indexPath.section].stationLineNum[indexPath.row][1] as String)
            cell.secondLineNumLabel.textColor = UIColor.whiteColor()
            cell.secondLineNumLabel.layer.cornerRadius = 3
            
            cell.firstLineNameLabel.text = Sections[indexPath.section].stationLineName[indexPath.row][0] as String
            cell.firstLineNameLabel.hidden = true
            
            cell.secondLineNameLabel.text = Sections[indexPath.section].stationLineName[indexPath.row][1] as String
            cell.secondLineNameLabel.hidden = true

            return cell
        }
        
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return Sections[section].section
    }
    
    
    func setLineLabelColor(stationLineNumber:String) -> UIColor {
        if stationLineNumber.containsString("BR") {
            return UIColor(red: 158/255, green: 101/255, blue: 46/255, alpha: 1)
        }
        else if stationLineNumber.containsString("R") && !stationLineNumber.containsString("B") && !stationLineNumber.containsString("A"){
            return UIColor(red: 203/255, green: 44/255, blue: 48/255, alpha: 1)
        }
        else if stationLineNumber.containsString("G") && !stationLineNumber.containsString("A") && !stationLineNumber.containsString("M") {
            return UIColor(red: 0/255, green: 119/255, blue: 73/255, alpha: 1)
        }
        else if stationLineNumber.containsString("G03A") {
            return UIColor(red: 206/255, green: 220/255, blue: 0/255, alpha: 1)
        }
        else if stationLineNumber.containsString("O") {
            return UIColor(red: 255/255, green: 163/255, blue: 0/255, alpha: 1)
        }
        
        else if stationLineNumber.containsString("MG") {
            return UIColor(red: 119/255, green: 185/255, blue: 51/255, alpha: 1)
        }
        else if stationLineNumber.containsString("B") && !stationLineNumber.containsString("R") {
            return UIColor(red: 0/255, green: 94/255, blue: 184/255, alpha: 1)
        }
        else {
            return UIColor(red: 248/255, green: 144/255, blue: 165/255, alpha: 1)
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "FirstCellShow" {
            let cell = sender as! FirstTableViewCell
            let destViewController = segue.destinationViewController as! FirstViewController
            destViewController.stationName = cell.stationNameLabel.text!
            destViewController.lineName = cell.lineNameLabel.text!
            
        }
            else if segue.identifier == "SecondCellShow" {

            let cell = sender as! SecondTableViewCell
            let destController = segue.destinationViewController as! SecondViewController
            destController.stationName = cell.stationNameLabel.text!
            destController.firstLineName = cell.firstLineNameLabel.text!
            destController.secondLineName = cell.secondLineNameLabel.text!
            
        }
    }
    
}
