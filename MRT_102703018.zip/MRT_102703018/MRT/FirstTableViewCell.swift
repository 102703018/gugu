//
//  TableViewCell.swift
//  MRT
//
//  Created by Cindy Ku on 2016/5/24.
//  Copyright © 2016年 iOSCourse. All rights reserved.
//

import UIKit

class FirstTableViewCell: UITableViewCell {

    
    @IBOutlet var stationNameLabel: UILabel!
    @IBOutlet var lineNumLabel: UILabel!
    @IBOutlet var lineNameLabel: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
